import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class VMTranslator {
    public static void main(String[] args) throws IOException {
        String fileName = args[0];
        int extIndex = fileName.lastIndexOf('.');
        Path inputPath = Paths.get(fileName);
        Path outputPath = Paths.get(fileName.substring(0, extIndex) + ".asm");
        Parser parser = new Parser(inputPath);
        CodeWriter writer = new CodeWriter(outputPath);
        try {
            while (parser.hasMoreCommands()) {
                parser.advance();
                switch (parser.currentCommand) {
                    case C_ARITHMETIC:
                        writer.writeArithmetic(parser.arg1, parser.commandSource, parser.commandNumber);
                        break;
                    case C_POP:
                    case C_PUSH: writer.writePushPop(parser.currentCommand, parser.commandSource,
                            parser.arg1, parser.arg2, parser.commandNumber);
                }
            }
        } finally {
            writer.close();
            parser.close();
        }
    }
}
